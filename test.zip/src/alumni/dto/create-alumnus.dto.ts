export class CreateAlumnusDto {}
