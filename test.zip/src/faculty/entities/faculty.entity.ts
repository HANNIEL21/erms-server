export class Faculty {}
